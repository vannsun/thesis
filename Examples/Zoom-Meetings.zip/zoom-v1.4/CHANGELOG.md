# 2020-05-11 Version 1.4
- always allow meeting/webinar creation, but show warning
  if course size exceeds available license
- enforce encoded password in join links
- import webinars by Zoom ID
# 2020-05-07 Version 1.3.1
- show actions in "my meetings" only for hosts and alternative hosts
- rename controllers to avoid conflicts with other meeting plugins
- do not import personal meeting rooms
- provide option to delete a meeting only in Stud.IP, but not in Zoom
- allow importing a meeting only for hosts and alternative hosts
# 2020-04-28 Version 1.2.1
- show correct start time for irregular meetings
# 2020-04-27 Version 1.2
- my meetings list
# 2020-04-24 Version 1.1
- add icon
# 2020-04-21 Version 1.0
- show message for Webinar necessity if more than 300 participants
# 2020-04-15 Version 0.5
- initial commit