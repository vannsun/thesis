<?php
namespace Moodle;

class UnconfiguredException extends \Exception {}
