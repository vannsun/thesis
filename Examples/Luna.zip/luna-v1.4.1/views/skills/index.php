<div id="luna-data" data-type="skills" data-update-url="<?= $controller->url_for('skills/load_skills') ?>"
     data-error-message="<?= dgettext('luna', 'Es ist ein Fehler aufgetreten.') ?>"></div>
