<div id="luna-data" data-type="tags" data-update-url="<?= $controller->url_for('tags/load_tags') ?>"
     data-error-message="<?= dgettext('luna', 'Es ist ein Fehler aufgetreten.') ?>"></div>
