# MumieTask - Changelog

All important changes to this plugin will be documented in this file.

## [v1.2] - 2020-10-13
### Fixed
- Fixed a JavaScript error that disabled MUMIE Task form because of French translation in course.json

## [v1.1] - 2020-06-17
### Fixed
- Resolved issue that caused hashes to be identical for different users

### Added
- MUMIE course names are now available in multiple languages
- Teachers can now create MUMIE Tasks for LEMON servers
