<?php
    if (isset($points)) {
        echo $points . '/100';
    } else {
        echo '<i>-</i>';
    }
