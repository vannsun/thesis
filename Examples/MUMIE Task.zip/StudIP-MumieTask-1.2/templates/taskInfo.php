<div style='padding: 5px; border-bottom: solid grey 1px'>
    <b style='margin-bottom: 5px;'>
        <?= $header; ?>
    </b>
    <div style='padding: 5px;'>
        <?= $body; ?>
    </div>
</div>