# StudIP-MumieTask

Please visit our [Wiki](https://wiki.mumie.net/wiki/Working-as-lms.md)!
